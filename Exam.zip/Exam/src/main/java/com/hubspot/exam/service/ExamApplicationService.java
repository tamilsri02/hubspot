package com.hubspot.exam.service;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;

import com.hubspot.exam.model.*;

@Service
public class ExamApplicationService {

	Map<String, List<EmailCountDateModel>> resultMap ;

	private final Logger logger = LogManager.getLogger(this.getClass());

	static class SortByDate implements Comparator<Date> {
		@Override
		public int compare(Date a, Date b) {
			return a.compareTo(b);
		}
	}

	/**
	 * Find the eligible Partners who has consecutive days to attend the meeting
	 * For each country Capture the Meeting start date , Attendee count &
	 * corresponding List of email id's who is eligible to attend the meeting In
	 * resultMap using EmailCountDateModel POJO
	 * @param root
	 */

	private void findEligiblePartners(Root root) {
		resultMap = new HashMap<>();
		List<Partners> listOfPartners = root.getPartners();
		// Iterate the List of Partners
		for (Partners partners : listOfPartners) {
			List<Date> listOfDates = partners.getAvailableDates();
			String country = partners.getCountry();

			// Sort the Dates for every Partner
			Collections.sort(listOfDates, new SortByDate());
			// Iterate the List of Dates
			for (int i = 0; i < listOfDates.size() - 1; i++) {
				LocalDate date1 = convertLocalDate(listOfDates.get(i));
				LocalDate date2 = convertLocalDate(listOfDates.get(i + 1));
				// Check the partner having consecutive days to attend the meeting
				if (date1.plusDays(1).equals(date2)) {
					EmailCountDateModel emailcountdatemodel = new EmailCountDateModel();
					List<EmailCountDateModel> listEmailCountDateModel = new ArrayList<>();
					// Check the Country present in map or not 
					if (resultMap.containsKey(country)) {
						List<EmailCountDateModel> existingList = resultMap.get(country);
						boolean isDateAlreadyExists = existingList.stream()
								.anyMatch(Model -> Model.getDate().equals(date1));
						// Check the date already exists in the List of EmailCountDateModel
						if (isDateAlreadyExists) {
							EmailCountDateModel existingModel = existingList.stream()
									.filter(Model -> Model.getDate().equals(date1)).findAny().orElse(null);
							//Increment the Attendee for the date 
							emailcountdatemodel.setCount(existingModel.getCount() + 1);
							List<String> listEmail = existingModel.getEmail();
							listEmail.add(partners.getEmail());
							emailcountdatemodel.setEmail(listEmail);
							emailcountdatemodel.setDate(date1);
							existingList.remove(existingModel);
							listEmailCountDateModel.add(emailcountdatemodel);
							existingList.addAll(listEmailCountDateModel);
							resultMap.put(country, existingList);
						} else {
							emailcountdatemodel.setDate(date1);
							emailcountdatemodel.setCount(1);
							List<String> listEmail = new ArrayList<>();
							listEmail.add(partners.getEmail());
							emailcountdatemodel.setEmail(listEmail);
							listEmailCountDateModel.add(emailcountdatemodel);
							existingList.addAll(listEmailCountDateModel);
							resultMap.put(country, existingList);

						}
					} else {
						emailcountdatemodel.setCount(1);
						emailcountdatemodel.setDate(date1);
						List<String> listEmail = new ArrayList<>();
						listEmail.add(partners.getEmail());
						emailcountdatemodel.setEmail(listEmail);
						listEmailCountDateModel.add(emailcountdatemodel);
						resultMap.put(country, listEmailCountDateModel);
					}
				}
			}

		}
		mapAndPostEligibleAttendees();
	}

	/**
	 * Map the resultMap to ResponseRoot to form the respose POJO
	 * And POST the EligibleAttendees to the give result end point
	 */
	private void mapAndPostEligibleAttendees() {
		List<Countries> listCountries = new ArrayList<Countries>();
		ResponseRoot resRoot = new ResponseRoot();
		for (Entry<String, List<EmailCountDateModel>> resultMapentry : resultMap.entrySet()) {
			Countries countries = new Countries();
			int maxVal = 0;
			String resultDate = null;
			List<String> resultEmailList = new ArrayList<>();
			for (EmailCountDateModel model : resultMapentry.getValue()) {
				if (model.getCount() > maxVal) {

					maxVal = model.getCount();
					resultDate = myToString(model.getDate());
					resultEmailList = model.getEmail();
				}
			}
			countries.setName(resultMapentry.getKey());
			countries.setStartDate(resultDate);
			List<String> listWithoutDuplicates = new ArrayList<>(new HashSet<>(resultEmailList));
			countries.setAttendees(listWithoutDuplicates);
			countries.setAttendeeCount(maxVal);
			listCountries.add(countries);
		}
		resRoot.setCountries(listCountries);
		ObjectMapper mapper = new ObjectMapper();
		try {
			String jsonInString = mapper.writeValueAsString(resRoot);
			//Call the Post endpoint
			postEligibleAttendees(jsonInString);
			jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(resRoot);
		} catch (IOException e) {
			logger.error("ERROR Occurred " + e);
		}
	}

	/**
	 * POST the EligibleAttendees to the give result end point
	 * @param String
	 */
	public void postEligibleAttendees(String jsonInString) {
		
		logger.info("");
		logger.info("***********************************************");
		logger.info("POST /result                                   ");
		logger.info("***********************************************");
		logger.info("");

		String url = "https://candidate.hubteam.com/candidateTest/v3/problem/result?userKey=284f8bbe1aafcceae1b52b80b44a";
		ClientHttpRequestFactory factory = new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory());
		RestTemplate restTemplate = new RestTemplate(factory);
		restTemplate.setInterceptors(Collections.singletonList(new RequestResponseLoggingInterceptor()));
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(jsonInString, httpHeaders);

		ResponseEntity<String> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.POST,
				entity, String.class);

		if (response.getStatusCode().equals(HttpStatus.OK)) {
			logger.info(response.getBody());
		}

	}

	/**
	 * Get the list of partners from the given dataset endpoint 
	 */
	public void getPartners() {
		
		logger.info("");
		logger.info("***********************************************");
		logger.info("GET /dataset                                   ");
		logger.info("***********************************************");
		logger.info("");

		String url = "https://candidate.hubteam.com/candidateTest/v3/problem/dataset?userKey=284f8bbe1aafcceae1b52b80b44a";
		ClientHttpRequestFactory factory = new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory());
		RestTemplate restTemplate = new RestTemplate(factory);
		restTemplate.setInterceptors(Collections.singletonList(new RequestResponseLoggingInterceptor()));
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<>(httpHeaders);

		ResponseEntity<Root> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.GET, entity,
				Root.class);

		if (response.getStatusCode().equals(HttpStatus.OK)) {
			findEligiblePartners(response.getBody());
		}

	}
	
	private LocalDate convertLocalDate(Date dateToConvert) {
		return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	}

	private static String myToString(LocalDate localDate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return localDate.format(formatter);
	}
	
}
