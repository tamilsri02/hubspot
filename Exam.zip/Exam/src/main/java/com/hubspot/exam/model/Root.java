package com.hubspot.exam.model;

import java.util.List;
public class Root
{
    private List<Partners> partners;

    public void setPartners(List<Partners> partners){
        this.partners = partners;
    }
    public List<Partners> getPartners(){
        return this.partners;
    }
}
