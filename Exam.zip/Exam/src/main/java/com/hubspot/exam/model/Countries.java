package com.hubspot.exam.model;

import java.util.List;
public class Countries
{
    private int attendeeCount;

    private List<String> attendees;

    private String name;

    private String startDate;

    public void setAttendeeCount(int attendeeCount){
        this.attendeeCount = attendeeCount;
    }
    public int getAttendeeCount(){
        return this.attendeeCount;
    }
    public void setAttendees(List<String> attendees){
        this.attendees = attendees;
    }
    public List<String> getAttendees(){
        return this.attendees;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }
    public void setStartDate(String startDate){
        this.startDate = startDate;
    }
    public String getStartDate(){
        return this.startDate;
    }
	@Override
	public String toString() {
		return "Countries [attendeeCount=" + attendeeCount + ", attendees=" + attendees + ", name=" + name
				+ ", startDate=" + startDate + "]";
	}
    
    
}
