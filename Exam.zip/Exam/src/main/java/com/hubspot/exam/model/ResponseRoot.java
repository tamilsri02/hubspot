package com.hubspot.exam.model;

import java.util.ArrayList;
import java.util.List;
public class ResponseRoot
{
    private List<Countries> countries;

    public void setCountries(List<Countries> countries){
        this.countries = countries;
    }
    public List<Countries> getCountries(){
        return this.countries;
    }
}
