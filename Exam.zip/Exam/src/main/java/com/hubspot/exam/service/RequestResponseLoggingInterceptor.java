package com.hubspot.exam.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.StreamUtils;
  
import java.io.IOException;
import java.nio.charset.Charset;
 
public class RequestResponseLoggingInterceptor implements ClientHttpRequestInterceptor {
      
    private final Logger log = LogManager.getLogger(this.getClass());
    
    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException 
    {
        logRequest(request, body);
        ClientHttpResponse response = execution.execute(request, body);
        logResponse(response);
        return response;
    }
  
    private void logRequest(HttpRequest request, byte[] body) throws IOException 
    {
        if (log.isDebugEnabled()) 
        {
        	log.debug(" ");
            log.debug("*************************** Request Begin ************************************************");
            log.debug(" ");
            log.debug("Request Details");
            log.debug("URI         : "+ request.getURI());
            log.debug("Method      : "+ request.getMethod().toString());
            log.debug("Request Headers     : "+ request.getHeaders());
            request.getHeaders().forEach((key, value) -> {
            	log.debug("\t " + String.format("Header '%s' *%s",key,value));
            });
            log.debug("Request body: "+ new String(body, "UTF-8"));
            log.debug(" ");
            log.debug("************************** Request End ************************************************");
            log.debug(" ");
        }
    }
  
    private void logResponse(ClientHttpResponse response) throws IOException 
    {
        if (log.isDebugEnabled()) 
        {
        	log.debug(" ");
            log.debug("**************************** Response Begin ******************************************");
            log.debug(" ");
            log.debug("Respose Details");
            log.debug("Response Status code  : "+ response.getStatusCode());
            log.debug("Status text  : "+ response.getStatusText());
            log.debug("Response Headers      : "+ response.getHeaders());
            response.getHeaders().forEach((key, value) -> {
            	log.debug("\t " + String.format("Header '%s' *%s",key,value));
            });
            log.debug("Response body: "+ StreamUtils.copyToString(response.getBody(), Charset.defaultCharset()));
            log.debug(" ");
            log.debug("*********************** Response End *************************************************");
            log.debug(" ");
        }
    }
}